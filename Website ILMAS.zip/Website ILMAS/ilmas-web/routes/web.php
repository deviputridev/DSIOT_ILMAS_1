<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ChatbotController;

Route::get('/', [DashboardController::class, 'index']);
Route::get('/api/sensor-now', [DashboardController::class, 'getLatestData']);
Route::get('/api/status-history', [DashboardController::class, 'getStatusHistory']);
Route::post('/api/chatbot', [ChatbotController::class, 'chat']);