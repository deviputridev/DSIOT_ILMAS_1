<?php

namespace App\Http\Controllers;

use App\Models\SensorLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class DashboardController extends Controller
{
    private function mapRow($row)
    {
        if (!$row) return null;
        return [
            'soil_moisture' => $row->moisture_percent ?? 0,
            'accel_x'       => $row->ax ?? 0,
            'accel_y'       => $row->ay ?? 0,
            'accel_z'       => $row->az ?? 0,
            'gyro_x'        => $row->gx ?? 0,
            'gyro_y'        => $row->gy ?? 0,
            'gyro_z'        => $row->gz ?? 0,
            'pitch'         => $row->pitch ?? 0,
            'roll'          => $row->roll ?? 0,
            'vibration'     => $row->vibration ?? 0,
            'status_ai'     => $row->status ?? 'UNKNOWN',
            'timestamp'     => $row->timestamp ?? null,
        ];
    }

    public function index()
    {
        $rawLogs    = SensorLog::orderBy('timestamp', 'asc')->get();
        $rawCurrent = SensorLog::orderBy('timestamp', 'desc')->first();

        $logs    = $rawLogs->map(fn($row) => (object) $this->mapRow($row));
        $current = (object) $this->mapRow($rawCurrent);

        $weatherInfo = 'Mengambil data...';
        try {
            $response = Http::get('https://api.bmkg.go.id/publik/prakiraan-cuaca?adm1=35');
            if ($response->successful()) {
                $data = $response->json();
                $foundSurabaya = false;
                if (isset($data['data'])) {
                    foreach ($data['data'] as $wilayah) {
                        if (isset($wilayah['lokasi']['creator']) && $wilayah['lokasi']['creator'] == 'Kota Surabaya') {
                            if (isset($wilayah['cuaca'][0][0]['weather_desc'])) {
                                $weatherInfo   = $wilayah['cuaca'][0][0]['weather_desc'];
                                $foundSurabaya = true;
                                break;
                            }
                        }
                    }
                }
                if (!$foundSurabaya) $weatherInfo = "Surabaya: Cerah Berawan";
            } else {
                $weatherInfo = "Layanan BMKG Offline";
            }
        } catch (\Exception $e) {
            $weatherInfo = "Gagal memuat cuaca";
        }

        return view('dashboard', compact('logs', 'current', 'weatherInfo'));
    }

    public function getLatestData()
    {
        $row = SensorLog::orderBy('timestamp', 'desc')->first();
        return response()->json($this->mapRow($row));
    }

    public function getStatusHistory()
    {
        $data = SensorLog::orderBy('timestamp', 'asc')
            ->get()
            ->map(fn($row) => [
                'timestamp' => $row->timestamp,
                'status'    => $row->status ?? 'UNKNOWN',
                'moisture'  => $row->moisture_percent ?? 0,
                'vibration' => $row->vibration ?? 0,
            ]);

        return response()->json($data);
    }
}