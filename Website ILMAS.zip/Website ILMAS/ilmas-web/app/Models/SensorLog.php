<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SensorLog extends Model
{
    protected $table = 'sensor_data';
    protected $primaryKey = 'id';
    public $timestamps = false;

    protected $fillable = [
        'timestamp', 'moisture', 'moisture_percent',
        'ax', 'ay', 'az', 'gx', 'gy', 'gz',
        'pitch', 'roll', 'vibration', 'status'
    ];
}
