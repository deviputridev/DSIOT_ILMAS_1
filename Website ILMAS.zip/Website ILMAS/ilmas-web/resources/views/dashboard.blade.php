<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ILMAS Control Center</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">

    <style>
        * { font-family: 'Inter', sans-serif; }
        .font-mono { font-family: 'JetBrains Mono', monospace; }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: #f1f5f9; }
        ::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: #94a3b8; }

        @keyframes pulse-ring {
            0% { transform: scale(0.93); opacity: 1; }
            80%, 100% { transform: scale(1.15); opacity: 0; }
        }
        .pulse-ring {
            animation: pulse-ring 2s cubic-bezier(0.215, 0.61, 0.355, 1) infinite;
        }
        @keyframes fade-slide-up {
            from { opacity: 0; transform: translateY(24px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-up { animation: fade-slide-up 0.6s ease forwards; }
        .animate-fade-up-delay-1 { animation: fade-slide-up 0.6s ease 0.15s forwards; opacity: 0; }
        .animate-fade-up-delay-2 { animation: fade-slide-up 0.6s ease 0.3s forwards; opacity: 0; }
        .animate-fade-up-delay-3 { animation: fade-slide-up 0.6s ease 0.45s forwards; opacity: 0; }

        #landing-page { transition: opacity 0.4s ease, transform 0.4s ease; }
        #dashboard-page { transition: opacity 0.4s ease, transform 0.4s ease; display: none; }

        .status-aman { background: #f0fdf4; border-color: #22c55e; }
        .status-waspada { background: #fefce8; border-color: #eab308; }
        .status-bahaya { background: #fff1f2; border-color: #f43f5e; }
        .status-unknown { background: #f8fafc; border-color: #94a3b8; }

        .bar-aman { width: var(--bar-w); background: #22c55e; }
        .bar-waspada { width: var(--bar-w); background: #eab308; }
        .bar-bahaya { width: var(--bar-w); background: #f43f5e; }
    </style>

    <script>
        const phpLogs    = @json($logs);
        const phpCurrent = @json($current ?? null);
        const phpWeather = @json($weatherInfo ?? 'N/A');
    </script>
</head>
<body class="bg-slate-50 antialiased text-slate-800 selection:bg-blue-200">


<div id="landing-page">

    <div class="fixed top-0 left-0 right-0 h-[600px] bg-gradient-to-b from-blue-50 via-indigo-50/30 to-transparent -z-10 pointer-events-none"></div>
    <div class="fixed top-20 right-[-10%] w-[500px] h-[500px] rounded-full bg-indigo-200/40 blur-3xl -z-10 pointer-events-none"></div>
    <div class="fixed top-[40%] left-[-10%] w-[400px] h-[400px] rounded-full bg-blue-100/50 blur-3xl -z-10 pointer-events-none"></div>

    <nav id="landingNav" class="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center bg-white/95 backdrop-blur-md sticky top-0 z-40 border-b border-slate-200">
        <div class="flex items-center space-x-3">
            <div class="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center shadow-md shadow-blue-200">
                <div class="w-3 h-3 bg-white rounded-full"></div>
            </div>
            <div>
                <h1 class="text-xl font-bold tracking-tight text-slate-900 leading-none">ILMAS</h1>
                <p class="text-[10px] uppercase tracking-widest text-slate-500 font-bold mt-0.5">Control Center</p>
            </div>
        </div>
        <div class="flex items-center space-x-6">
            <a href="#features" class="text-sm font-medium text-slate-600 hover:text-blue-600 transition-colors hidden md:inline">Features</a>
            <a href="#algorithms" class="text-sm font-medium text-slate-600 hover:text-blue-600 transition-colors hidden md:inline">Algorithms</a>
            <a href="#developers" class="text-sm font-medium text-slate-600 hover:text-blue-600 transition-colors hidden md:inline">Developers</a>
            <button onclick="enterDashboard()" class="group px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-xl shadow-lg shadow-blue-200 transition-all flex items-center space-x-2">
                <span>Live Control Center</span>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="group-hover:translate-x-1 transition-transform"><path d="M9 18l6-6-6-6"/></svg>
            </button>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-6 pb-24">

        <section class="pt-20 md:pt-28 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center animate-fade-up">
            <div class="lg:col-span-7 flex flex-col justify-center">
                <div class="inline-flex items-center space-x-2 bg-blue-50 border border-blue-100 px-3.5 py-1.5 rounded-full mb-6 w-fit">
                    <span class="flex h-2 w-2 rounded-full bg-blue-600 animate-pulse"></span>
                    <span class="text-xs font-semibold text-blue-700 tracking-wide font-mono">LSTM-SOS & RANDOM FOREST INTEGRATION</span>
                </div>
                <h1 class="text-5xl md:text-6xl font-black tracking-tight text-slate-900 leading-tight mb-6">
                    Intelligent<br>
                    <span class="text-blue-600">Landslide</span><br>
                    Monitoring
                </h1>
                <p class="text-lg text-slate-600 leading-relaxed mb-8 max-w-lg">
                    Sistem peringatan dini longsor generasi terbaru yang mengintegrasikan sensor IoT multi-parameter, kecerdasan buatan, dan data cuaca BMKG secara real-time.
                </p>
                <div class="flex flex-wrap gap-4">
                    <button onclick="enterDashboard()" class="group px-7 py-3.5 bg-blue-600 hover:bg-blue-700 text-white text-base font-bold rounded-2xl shadow-xl shadow-blue-200 transition-all flex items-center space-x-2.5">
                        <span>Buka Control Center</span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="group-hover:translate-x-1 transition-transform"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                    </button>
                    <a href="#features" class="px-7 py-3.5 bg-white border-2 border-slate-200 hover:border-slate-300 text-slate-700 text-base font-bold rounded-2xl transition-all">
                        Pelajari Lebih Lanjut
                    </a>
                </div>
                <!-- Live stats pills -->
                <div class="mt-10 flex flex-wrap gap-3">
                    @if($current)
                    <div class="flex items-center gap-2 bg-white/80 backdrop-blur border border-slate-200 px-3 py-1.5 rounded-full">
                        <span class="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
                        <span class="text-xs font-semibold text-slate-600">Live Data Active</span>
                    </div>
                    <div class="flex items-center gap-2 bg-white/80 backdrop-blur border border-slate-200 px-3 py-1.5 rounded-full">
                        <span class="text-xs font-mono text-slate-500">Cuaca: {{ $weatherInfo }}</span>
                    </div>
                    @endif
                </div>
            </div>
            <div class="lg:col-span-5 animate-fade-up-delay-1">
                <!-- Visual Status Panel Preview -->
                <div class="bg-white rounded-3xl shadow-2xl shadow-slate-200/50 border border-slate-200/60 p-6">
                    <div class="flex items-center justify-between mb-4">
                        <div class="flex items-center gap-2">
                            <div class="w-2 h-2 rounded-full bg-red-400"></div>
                            <div class="w-2 h-2 rounded-full bg-yellow-400"></div>
                            <div class="w-2 h-2 rounded-full bg-green-400"></div>
                        </div>
                        <span class="text-xs font-mono text-slate-400">ilmas-control-center</span>
                    </div>
                    @if($current)
                    <div class="@php
                        $s = strtoupper($current->status_ai);
                        echo ($s === 'BAHAYA') ? 'bg-rose-50 border-rose-200' : (($s === 'WASPADA') ? 'bg-yellow-50 border-yellow-200' : 'bg-emerald-50 border-emerald-200');
                    @endphp rounded-2xl border p-4 mb-4">
                        <p class="text-xs font-bold uppercase tracking-widest @php echo ($s === 'BAHAYA') ? 'text-rose-400' : (($s === 'WASPADA') ? 'text-yellow-500' : 'text-emerald-500'); @endphp mb-1">System Condition</p>
                        <p class="text-2xl font-black @php echo ($s === 'BAHAYA') ? 'text-rose-700' : (($s === 'WASPADA') ? 'text-yellow-700' : 'text-emerald-700'); @endphp">
                            @if($s === 'BAHAYA') ⚠ BAHAYA : EVAKUASI
                            @elseif($s === 'WASPADA') ⚡ WASPADA : SIAGA
                            @else ✓ SISTEM AMAN
                            @endif
                        </p>
                    </div>
                    <div class="grid grid-cols-3 gap-3">
                        <div class="bg-slate-50 rounded-xl p-3 border border-slate-200">
                            <p class="text-[10px] text-slate-400 uppercase tracking-wide mb-1">Moisture</p>
                            <p class="text-xl font-bold font-mono text-slate-800">{{ number_format($current->soil_moisture, 1) }}<span class="text-xs font-normal text-slate-400">%</span></p>
                        </div>
                        <div class="bg-slate-50 rounded-xl p-3 border border-slate-200">
                            <p class="text-[10px] text-slate-400 uppercase tracking-wide mb-1">Vibrasi</p>
                            <p class="text-xl font-bold font-mono text-slate-800">{{ number_format($current->vibration ?? 0, 2) }}</p>
                        </div>
                        <div class="bg-slate-50 rounded-xl p-3 border border-slate-200">
                            <p class="text-[10px] text-slate-400 uppercase tracking-wide mb-1">Pitch</p>
                            <p class="text-xl font-bold font-mono text-slate-800">{{ number_format($current->pitch ?? 0, 1) }}<span class="text-xs font-normal text-slate-400">°</span></p>
                        </div>
                    </div>
                    @else
                    <div class="text-center py-10 text-slate-400">
                        <p class="text-sm">Belum ada data sensor</p>
                    </div>
                    @endif
                </div>
            </div>
        </section>

        <section id="features" class="mt-28 animate-fade-up-delay-2">
            <div class="text-center mb-14">
                <span class="text-xs font-bold uppercase tracking-widest text-blue-600 font-mono">Kemampuan Sistem</span>
                <h2 class="text-4xl font-black text-slate-900 mt-2">Monitoring Multi-Layer</h2>
                <p class="text-slate-500 mt-3 max-w-md mx-auto">Tiga lapisan deteksi yang bekerja simultan untuk keandalan prediksi maksimum.</p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div class="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                    <div class="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center mb-4">
                        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#2563eb" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/></svg>
                    </div>
                    <h3 class="font-bold text-slate-900 mb-2">Sensor IoT Real-time</h3>
                    <p class="text-sm text-slate-500 leading-relaxed">Accelerometer 3-axis, gyroscope, sensor kelembaban tanah, dan detektor getaran terintegrasi penuh.</p>
                </div>
                <div class="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                    <div class="w-12 h-12 bg-purple-50 rounded-xl flex items-center justify-center mb-4">
                        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#7c3aed" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="3"/><path d="M3 9h18M9 21V9"/></svg>
                    </div>
                    <h3 class="font-bold text-slate-900 mb-2">Model AI Hybrid</h3>
                    <p class="text-sm text-slate-500 leading-relaxed">LSTM-SOS mendeteksi pola temporal. Random Forest memvalidasi klasifikasi risiko dari 4 parameter utama.</p>
                </div>
                <div class="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                    <div class="w-12 h-12 bg-emerald-50 rounded-xl flex items-center justify-center mb-4">
                        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#059669" stroke-width="2"><path d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
                    </div>
                    <h3 class="font-bold text-slate-900 mb-2">Integrasi BMKG</h3>
                    <p class="text-sm text-slate-500 leading-relaxed">Data cuaca langsung dari API BMKG Jawa Timur untuk validasi kontekstual kondisi hujan dan lingkungan.</p>
                </div>
            </div>
        </section>

        <section id="algorithms" class="mt-24">
            <div class="text-center mb-14">
                <span class="text-xs font-bold uppercase tracking-widest text-purple-600 font-mono">Teknologi Inti</span>
                <h2 class="text-4xl font-black text-slate-900 mt-2">Arsitektur Model AI</h2>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="bg-gradient-to-br from-blue-600 to-indigo-700 rounded-2xl p-7 text-white shadow-xl shadow-blue-200">
                    <div class="flex items-center gap-3 mb-4">
                        <span class="text-xs font-bold uppercase tracking-widest text-blue-200 font-mono bg-white/10 px-2 py-1 rounded-md">Layer 1</span>
                        <h3 class="text-xl font-black">LSTM-SOS Network</h3>
                    </div>
                    <p class="text-blue-100 text-sm leading-relaxed mb-4">Long Short-Term Memory dengan mekanisme Self-Organizing State untuk mendeteksi pola temporal pergerakan tanah. Menganalisis tren sensor selama 24 jam terakhir.</p>
                    <div class="grid grid-cols-2 gap-3">
                        <div class="bg-white/10 rounded-xl p-3">
                            <p class="text-xs text-blue-200">Input Timestep</p>
                            <p class="text-lg font-bold font-mono">24h</p>
                        </div>
                        <div class="bg-white/10 rounded-xl p-3">
                            <p class="text-xs text-blue-200">Hidden Units</p>
                            <p class="text-lg font-bold font-mono">128</p>
                        </div>
                    </div>
                </div>
                <div class="bg-gradient-to-br from-emerald-600 to-teal-700 rounded-2xl p-7 text-white shadow-xl shadow-emerald-200">
                    <div class="flex items-center gap-3 mb-4">
                        <span class="text-xs font-bold uppercase tracking-widest text-emerald-200 font-mono bg-white/10 px-2 py-1 rounded-md">Layer 2</span>
                        <h3 class="text-xl font-black">Random Forest</h3>
                    </div>
                    <p class="text-emerald-100 text-sm leading-relaxed mb-4">Ensemble 100 decision tree yang mengklasifikasikan status AMAN / WASPADA / BAHAYA berdasarkan moisture, vibrasi, akselerometer, dan intensitas hujan.</p>
                    <div class="grid grid-cols-2 gap-3">
                        <div class="bg-white/10 rounded-xl p-3">
                            <p class="text-xs text-emerald-200">N-Estimators</p>
                            <p class="text-lg font-bold font-mono">100</p>
                        </div>
                        <div class="bg-white/10 rounded-xl p-3">
                            <p class="text-xs text-emerald-200">Features</p>
                            <p class="text-lg font-bold font-mono">4</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section id="developers" class="mt-24">
            <div class="text-center mb-14">
                <span class="text-xs font-bold uppercase tracking-widest text-rose-600 font-mono">Developers</span>
                <h2 class="text-4xl font-black text-slate-900 mt-2">Kelompok 1 - Desain dan Aplikasi Internet of Things</h2>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                @php
                $devs = [
                    [
                        'name' => 'Xyz Frizy Firstyaji',
                        'nim' => '5024221073',
                        'role' => 'AI Engineer',
                        'letter' => 'F',
                        'gradient' => 'from-blue-500 to-indigo-600'
                    ],
                    [
                        'name' => 'Athaya Khairani Adi',
                        'nim' => '5024241007',
                        'role' => 'Sensor and Database Configuration',
                        'extra_role' => 'Web Developer',
                        'letter' => 'A',
                        'gradient' => 'from-emerald-400 to-teal-600'
                    ],
                    [
                        'name' => 'Muhammad Sayyid Tsabit',
                        'nim' => '5024241013',
                        'role' => '3D and Prototype Designer',
                        'letter' => 'S',
                        'gradient' => 'from-amber-400 to-orange-600'
                    ],
                    [
                        'name' => 'Devi Putri Sekar Arum',
                        'nim' => '5024241049',
                        'role' => 'Machine Learning Engineer',
                        'extra_role' => 'Web Developer',
                        'letter' => 'D',
                        'gradient' => 'from-rose-400 to-pink-600'
                    ],
                ];
                @endphp
                @foreach($devs as $dev)
                <div class="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm text-center hover:shadow-md transition-shadow">
                    <div class="w-14 h-14 rounded-2xl bg-gradient-to-br {{ $dev['gradient'] }} flex items-center justify-center mx-auto mb-4 shadow-lg">
                        <span class="text-white font-black text-xl">{{ $dev['letter'] }}</span>
                    </div>

                    <h4 class="font-bold text-slate-900 text-sm mb-1">
                        {{ $dev['name'] }}
                    </h4>

                    <p class="text-xs font-mono text-slate-400 mb-2">
                        {{ $dev['nim'] }}
                    </p>

                    <p class="text-xs text-slate-500 leading-relaxed">
                        {{ $dev['role'] }}
                    </p>

                    @if(isset($dev['extra_role']))
                        <p class="text-xs text-slate-500 leading-relaxed">
                            {{ $dev['extra_role'] }}
                        </p>
                    @endif
                </div>
                @endforeach
            </div>
        </section>

        <!-- CTA -->
        <section class="mt-24 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-3xl p-12 text-center shadow-2xl shadow-blue-200">
            <h2 class="text-3xl font-black text-white mb-4">Siap Memantau?</h2>
            <p class="text-blue-100 mb-8 max-w-md mx-auto">Akses dashboard real-time untuk melihat kondisi sensor terkini dan riwayat telemetri lengkap.</p>
            <button onclick="enterDashboard()" class="group px-8 py-4 bg-white text-blue-700 font-black text-base rounded-2xl shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all flex items-center gap-3 mx-auto">
                <span>Buka Live Dashboard</span>
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="group-hover:translate-x-1 transition-transform"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
            </button>
        </section>
    </div>
</div>

<div id="dashboard-page" style="display:none;">

    <nav class="bg-white/95 backdrop-blur-md text-slate-950 px-6 py-4 shadow-sm border-b border-slate-200 sticky top-0 z-30 flex flex-col md:flex-row md:justify-between md:items-center gap-4">
        <div class="flex items-center justify-between">
            <div class="flex items-center space-x-3">
                <button onclick="backToLanding()" class="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 rounded-xl text-slate-600 text-xs font-bold transition-all flex items-center gap-1.5">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M15 18l-6-6 6-6"/></svg>
                    Kembali
                </button>
                <div class="h-6 w-px bg-slate-200"></div>
                <div class="flex items-center gap-2.5">
                    <div class="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center shadow-md shadow-blue-200">
                        <div class="w-3 h-3 bg-white rounded-full"></div>
                    </div>
                    <div>
                        <h1 class="text-xl font-bold tracking-tight text-slate-900 leading-none">ILMAS</h1>
                        <p class="text-[10px] uppercase tracking-widest text-slate-500 font-semibold mt-0.5">Control Center</p>
                    </div>
                </div>
            </div>
            <div class="md:hidden flex items-center gap-2 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-100">
                <span class="flex h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                <span class="text-[9px] font-bold text-emerald-700 uppercase tracking-tight">Sync Active</span>
            </div>
        </div>
        <div class="flex flex-wrap items-center gap-3">
            <div class="hidden md:flex items-center gap-2 bg-emerald-50 px-3 py-1.5 rounded-full border border-emerald-100">
                <span class="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span class="text-xs font-bold text-emerald-700 uppercase tracking-tight">Sync Active</span>
            </div>
            <div class="bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200 flex flex-col justify-center">
                <span class="text-[10px] uppercase tracking-widest text-slate-500 font-bold block">BMKG Weather</span>
                <span class="font-mono text-xs text-slate-700 mt-0.5" id="bmkg-display">{{ $weatherInfo }}</span>
            </div>
        </div>
    </nav>

    <main class="container mx-auto p-4 md:p-6 max-w-7xl">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">

            <div class="lg:col-span-8 space-y-6">

                @php
                    $status = strtoupper($current->status_ai ?? 'UNKNOWN');
                    $isBahaya = $status === 'BAHAYA';
                    $isWaspada = $status === 'WASPADA';
                    if ($isBahaya) {
                        $statusBg = 'bg-rose-50 border-rose-500';
                        $statusTextColor = 'text-rose-700';
                        $statusLabel = '⚠ BAHAYA : EVAKUASI SEGERA';
                    } elseif ($isWaspada) {
                        $statusBg = 'bg-yellow-50 border-yellow-500';
                        $statusTextColor = 'text-yellow-700';
                        $statusLabel = '⚡ WASPADA : SIAGA PENUH';
                    } else {
                        $statusBg = 'bg-white border-emerald-500';
                        $statusTextColor = 'text-emerald-700';
                        $statusLabel = '✓ SISTEM AMAN';
                    }
                @endphp

                <div id="statusCard" class="transition-all duration-300 rounded-2xl shadow-sm p-6 flex flex-col md:flex-row md:items-center justify-between border-l-4 gap-4 {{ $statusBg }}">
                    <div>
                        <h2 class="text-[10px] font-bold uppercase tracking-widest text-slate-500 mb-1 flex items-center gap-1.5">
                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                            Status Kondisi Sistem
                        </h2>
                        <p id="statusText" class="text-3xl font-extrabold tracking-tight {{ $statusTextColor }}">{{ $statusLabel }}</p>
                        <div class="flex items-center gap-3 mt-1 text-xs text-slate-500">
                            <span>Status DB: <strong class="font-mono text-slate-700">{{ $status }}</strong></span>
                        </div>
                    </div>
                    <div class="md:border-l md:border-slate-200/60 md:pl-6">
                        <p class="text-[10px] font-bold uppercase tracking-widest text-slate-500 mb-1">Last Telemetry Update</p>
                        <p id="lastUpdate" class="font-mono text-sm md:text-base font-semibold text-slate-700 flex items-center md:justify-end gap-1.5">
                            <span class="h-2 w-2 rounded-full bg-blue-500 inline-block"></span>
                            {{ $current->timestamp ?? '-' }}
                        </p>
                    </div>
                </div>

                <!-- Sensor Cards Row -->
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">

                    <!-- Soil Moisture -->
                    <div class="bg-white rounded-2xl shadow-sm p-5 border border-slate-200/80 flex flex-col justify-between">
                        <div>
                            <h3 class="text-[11px] uppercase tracking-wider text-slate-400 font-bold mb-3 border-b border-slate-100 pb-2">Soil Moisture</h3>
                            <div class="flex items-baseline space-x-1">
                                <p id="valMoisture" class="text-3xl font-light text-slate-800 font-mono">{{ number_format($current->soil_moisture ?? 0, 1) }}</p>
                                <span class="text-sm font-semibold text-slate-400">%</span>
                            </div>
                        </div>
                        <div class="w-full bg-slate-100 rounded-full h-1.5 mt-4">
                            @php $mPct = min(100, max(0, $current->soil_moisture ?? 0)); @endphp
                            <div class="h-1.5 rounded-full transition-all duration-300 {{ $mPct > 75 ? 'bg-rose-500' : ($mPct > 55 ? 'bg-yellow-500' : 'bg-blue-500') }}" style="width: {{ $mPct }}%"></div>
                        </div>
                    </div>

                    <!-- Accelerometer -->
                    <div class="bg-white rounded-2xl shadow-sm p-5 border border-slate-200/80">
                        <h3 class="text-[11px] uppercase tracking-wider text-slate-400 font-bold mb-3 border-b border-slate-100 pb-2">Accelerometer (m/s²)</h3>
                        <div id="valAccel" class="grid grid-cols-3 gap-2 text-center font-mono">
                            <div>
                                <span class="block text-[10px] text-slate-400 mb-1">X</span>
                                <span class="text-base font-medium">{{ number_format($current->accel_x ?? 0, 2) }}</span>
                            </div>
                            <div>
                                <span class="block text-[10px] text-slate-400 mb-1">Y</span>
                                <span class="text-base font-medium">{{ number_format($current->accel_y ?? 0, 2) }}</span>
                            </div>
                            <div>
                                <span class="block text-[10px] text-slate-400 mb-1">Z</span>
                                <span class="text-base font-medium">{{ number_format($current->accel_z ?? 0, 2) }}</span>
                            </div>
                        </div>
                    </div>

                    <!-- Gyroscope -->
                    <div class="bg-white rounded-2xl shadow-sm p-5 border border-slate-200/80">
                        <h3 class="text-[11px] uppercase tracking-wider text-slate-400 font-bold mb-3 border-b border-slate-100 pb-2">Gyroscope (rad/s)</h3>
                        <div id="valGyro" class="grid grid-cols-3 gap-2 text-center font-mono">
                            <div>
                                <span class="block text-[10px] text-slate-400 mb-1">X</span>
                                <span class="text-base font-medium">{{ number_format($current->gyro_x ?? 0, 2) }}</span>
                            </div>
                            <div>
                                <span class="block text-[10px] text-slate-400 mb-1">Y</span>
                                <span class="text-base font-medium">{{ number_format($current->gyro_y ?? 0, 2) }}</span>
                            </div>
                            <div>
                                <span class="block text-[10px] text-slate-400 mb-1">Z</span>
                                <span class="text-base font-medium">{{ number_format($current->gyro_z ?? 0, 2) }}</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Pitch / Roll / Vibration -->
                <div class="grid grid-cols-3 gap-4">
                    <div class="bg-white rounded-2xl shadow-sm p-5 border border-slate-200/80 text-center">
                        <p class="text-[11px] uppercase tracking-wider text-slate-400 font-bold mb-2">Pitch</p>
                        <p id="valPitch" class="text-2xl font-bold font-mono text-slate-800">{{ number_format($current->pitch ?? 0, 2) }}<span class="text-sm text-slate-400">°</span></p>
                    </div>
                    <div class="bg-white rounded-2xl shadow-sm p-5 border border-slate-200/80 text-center">
                        <p class="text-[11px] uppercase tracking-wider text-slate-400 font-bold mb-2">Roll</p>
                        <p id="valRoll" class="text-2xl font-bold font-mono text-slate-800">{{ number_format($current->roll ?? 0, 2) }}<span class="text-sm text-slate-400">°</span></p>
                    </div>
                    <div class="bg-white rounded-2xl shadow-sm p-5 border border-slate-200/80 text-center">
                        <p class="text-[11px] uppercase tracking-wider text-slate-400 font-bold mb-2">Vibrasi</p>
                        <p id="valVibration" class="text-2xl font-bold font-mono text-slate-800">{{ number_format($current->vibration ?? 0, 3) }}</p>
                    </div>
                </div>

                <!-- Moisture Chart -->
                <div class="bg-white rounded-2xl shadow-sm p-5 border border-slate-200">
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="text-xs uppercase tracking-widest text-slate-500 font-bold">Soil Moisture History</h3>
                        <div class="flex items-center gap-2">
                            <button onclick="prevMoist()" class="text-xs px-2 py-1 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-600 transition-colors">&#8592;</button>
                            <span id="moistSlideInfo" class="text-[10px] text-slate-400 font-mono min-w-[70px] text-center">Slide 1 / 1</span>
                            <button onclick="nextMoist()" class="text-xs px-2 py-1 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-600 transition-colors">&#8594;</button>
                        </div>
                    </div>
                    <canvas id="moistureChart" height="100"></canvas>
                </div>

                <!-- Accelerometer Chart -->
                <div class="bg-white rounded-2xl shadow-sm p-5 border border-slate-200">
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="text-xs uppercase tracking-widest text-slate-500 font-bold">Accelerometer History</h3>
                        <div class="flex items-center gap-2">
                            <button onclick="prevAccel()" class="text-xs px-2 py-1 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-600 transition-colors">&#8592;</button>
                            <span id="accelSlideInfo" class="text-[10px] text-slate-400 font-mono min-w-[70px] text-center">Slide 1 / 1</span>
                            <button onclick="nextAccel()" class="text-xs px-2 py-1 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-600 transition-colors">&#8594;</button>
                        </div>
                    </div>
                    <canvas id="accelChart" height="100"></canvas>
                </div>

                <!-- Status History Chart -->
                <div class="bg-white rounded-2xl shadow-sm p-5 border border-slate-200">
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="text-xs uppercase tracking-widest text-slate-500 font-bold">Landslide Status History</h3>
                        <div class="flex items-center gap-2">
                            <button onclick="prevSlide()" class="text-xs px-2 py-1 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-600 transition-colors">&#8592; Prev</button>
                            <span id="slideInfo" class="text-[10px] text-slate-400 font-mono min-w-[70px] text-center">Slide 1 / 1</span>
                            <button onclick="nextSlide()" class="text-xs px-2 py-1 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-600 transition-colors">Next &#8594;</button>
                        </div>
                    </div>
                    <canvas id="statusChart" height="100"></canvas>
                </div>
            </div>

            <!-- RIGHT COLUMN: Sidebar -->
            <div class="lg:col-span-4 space-y-5">

                <!-- Auto Refresh Toggle -->
                <div class="bg-white rounded-2xl shadow-sm p-5 border border-slate-200">
                    <div class="flex items-center justify-between mb-3">
                        <h3 class="text-xs uppercase tracking-widest text-slate-500 font-bold">Auto Refresh</h3>
                        <button id="refreshToggleBtn" onclick="toggleAutoRefresh()" class="px-3 py-1 text-xs font-bold rounded-lg bg-emerald-100 text-emerald-700 hover:bg-emerald-200 transition-colors">
                            ● Aktif
                        </button>
                    </div>
                    <p class="text-xs text-slate-400 leading-relaxed">Data sensor diperbarui otomatis setiap <strong class="text-slate-600">10 detik</strong> dari endpoint <code class="font-mono text-blue-600 bg-blue-50 px-1 rounded">/api/sensor-now</code>.</p>
                    <div class="mt-3 text-xs text-slate-400">
                        Terakhir refresh: <span id="lastRefreshTime" class="font-mono text-slate-600">—</span>
                    </div>
                </div>

                <!-- Chatbot Panel -->
                <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                    <div class="px-5 py-4 border-b border-slate-100 flex items-center gap-2">
                        <div class="w-7 h-7 bg-indigo-600 rounded-lg flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>
                        </div>
                        <div>
                            <h3 class="text-sm font-bold text-slate-900">ILMAS AI Engine</h3>
                            <p class="text-[10px] text-slate-400">Powered by Gemini AI</p>
                        </div>
                    </div>
                    <div id="chatLog" class="h-52 overflow-y-auto p-4 space-y-3 text-xs">
                        <div class="flex gap-2">
                            <div class="w-6 h-6 rounded-full bg-indigo-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                                <span class="text-[9px] font-bold text-indigo-600">AI</span>
                            </div>
                            <div class="bg-slate-50 rounded-xl px-3 py-2 text-slate-600 max-w-[85%]">
                                EWS ILMAS siap. Kirim kueri kondisi sensor atau status longsor.
                            </div>
                        </div>
                    </div>
                    <div class="border-t border-slate-100 p-3 flex gap-2">
                        <input id="chatInput" type="text" placeholder="Tanya kondisi sensor..." class="flex-1 text-xs bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-300 text-slate-700">
                        <button onclick="sendChat()" class="px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl transition-colors flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z"/></svg>
                        </button>
                    </div>
                </div>

                <!-- Telemetry Log Table -->
                <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                    <div class="px-5 py-4 border-b border-slate-100">
                        <h3 class="text-xs uppercase tracking-widest text-slate-500 font-bold">Riwayat Log ({{ count($logs) }} entri)</h3>
                    </div>
                    <div class="overflow-x-auto max-h-72 overflow-y-auto">
                        <table class="w-full text-xs">
                            <thead class="bg-slate-50 sticky top-0">
                                <tr>
                                    <th class="text-left px-4 py-2.5 text-slate-400 font-bold uppercase tracking-wider">Waktu</th>
                                    <th class="text-right px-3 py-2.5 text-slate-400 font-bold uppercase tracking-wider">Moist%</th>
                                    <th class="text-right px-3 py-2.5 text-slate-400 font-bold uppercase tracking-wider">Vibr</th>
                                    <th class="text-center px-3 py-2.5 text-slate-400 font-bold uppercase tracking-wider">Status</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-50">
                                @forelse($logs->sortByDesc('timestamp')->take(50) as $log)
                                @php
                                    $ls = strtoupper($log->status_ai ?? 'UNKNOWN');
                                    $lsBg = $ls === 'BAHAYA' ? 'bg-rose-100 text-rose-700' : ($ls === 'WASPADA' ? 'bg-yellow-100 text-yellow-700' : 'bg-emerald-100 text-emerald-700');
                                @endphp
                                <tr class="hover:bg-slate-50/50 transition-colors">
                                    <td class="px-4 py-2.5 font-mono text-slate-500 text-[10px]">
                                        {{ \Carbon\Carbon::parse($log->timestamp)->format('d M H:i') }}
                                    </td>
                                    <td class="px-3 py-2.5 text-right font-mono text-slate-700">{{ number_format($log->soil_moisture ?? 0, 1) }}</td>
                                    <td class="px-3 py-2.5 text-right font-mono text-slate-700">{{ number_format($log->vibration ?? 0, 3) }}</td>
                                    <td class="px-3 py-2.5 text-center">
                                        <span class="px-2 py-0.5 rounded-full text-[9px] font-bold {{ $lsBg }}">{{ $ls }}</span>
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="4" class="px-4 py-8 text-center text-slate-400">Belum ada data log.</td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </main>
</div>

<script>
Chart.defaults.font.family = 'Inter, ui-sans-serif, sans-serif';
Chart.defaults.color = '#64748b';

const PAGE = 10;

function enterDashboard() {
    const lp = document.getElementById('landing-page');
    const dp = document.getElementById('dashboard-page');
    lp.style.opacity = '0';
    lp.style.transform = 'translateY(-10px)';
    setTimeout(() => {
        lp.style.display = 'none';
        dp.style.display = 'block';
        dp.style.opacity = '0';
        dp.style.transform = 'translateY(10px)';
        setTimeout(() => {
            dp.style.opacity = '1';
            dp.style.transform = 'translateY(0)';
            initCharts();
            startAutoRefresh();
        }, 50);
    }, 350);
}

function backToLanding() {
    const lp = document.getElementById('landing-page');
    const dp = document.getElementById('dashboard-page');
    dp.style.opacity = '0';
    dp.style.transform = 'translateY(-10px)';
    setTimeout(() => {
        dp.style.display = 'none';
        lp.style.display = 'block';
        lp.style.opacity = '0';
        lp.style.transform = 'translateY(10px)';
        setTimeout(() => {
            lp.style.opacity = '1';
            lp.style.transform = 'translateY(0)';
        }, 50);
    }, 350);
}

function fmtLabel(ts) {
    if (!ts) return 'N/A';
    const d = new Date(ts);
    if (isNaN(d.getTime())) return ts;
    const day = String(d.getDate()).padStart(2, '0');
    const mon = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][d.getMonth()];
    const hh = String(d.getHours()).padStart(2, '0');
    const mm = String(d.getMinutes()).padStart(2, '0');
    return day + ' ' + mon + ' ' + hh + ':' + mm;
}

let moistSlide = 0, accelSlide = 0, currentSlide = 0;
let moistureChart = null, accelChart = null, statusChart = null;
let allStatusData = [];

function statusToNumber(s) {
    const su = (s || '').toUpperCase();
    if (su === 'AMAN') return 1;
    if (su === 'WASPADA') return 2;
    if (su === 'BAHAYA') return 3;
    return 0;
}

function getStatusColor(s) {
    const su = (s || '').toUpperCase();
    if (su === 'AMAN') return { bg: 'rgba(34,197,94,0.25)', border: '#22c55e' };
    if (su === 'WASPADA') return { bg: 'rgba(234,179,8,0.25)', border: '#eab308' };
    if (su === 'BAHAYA') return { bg: 'rgba(244,63,94,0.25)', border: '#f43f5e' };
    return { bg: 'rgba(148,163,184,0.2)', border: '#94a3b8' };
}

function renderMoistureSlide() {
    const total = Math.max(1, Math.ceil(phpLogs.length / PAGE));
    const slice = phpLogs.slice(moistSlide * PAGE, (moistSlide + 1) * PAGE);
    document.getElementById('moistSlideInfo').textContent = 'Slide ' + (moistSlide + 1) + ' / ' + total;
    if (moistureChart) moistureChart.destroy();
    moistureChart = new Chart(document.getElementById('moistureChart'), {
        type: 'line',
        data: {
            labels: slice.map(d => fmtLabel(d.timestamp)),
            datasets: [{
                label: 'Moisture %',
                data: slice.map(d => d.soil_moisture),
                borderColor: '#3b82f6',
                backgroundColor: 'rgba(59,130,246,0.08)',
                fill: true, tension: 0.4, pointRadius: 3, borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { display: false } },
            scales: { y: { min: 0, max: 100, grid: { color: '#f1f5f9' } }, x: { grid: { color: '#f1f5f9' } } }
        }
    });
}

function prevMoist() { if (moistSlide > 0) { moistSlide--; renderMoistureSlide(); } }
function nextMoist() { if (moistSlide < Math.ceil(phpLogs.length / PAGE) - 1) { moistSlide++; renderMoistureSlide(); } }

function renderAccelSlide() {
    const total = Math.max(1, Math.ceil(phpLogs.length / PAGE));
    const slice = phpLogs.slice(accelSlide * PAGE, (accelSlide + 1) * PAGE);
    document.getElementById('accelSlideInfo').textContent = 'Slide ' + (accelSlide + 1) + ' / ' + total;
    if (accelChart) accelChart.destroy();
    accelChart = new Chart(document.getElementById('accelChart'), {
        type: 'line',
        data: {
            labels: slice.map(d => fmtLabel(d.timestamp)),
            datasets: [
                { label: 'X', data: slice.map(d => d.accel_x), borderColor: '#ef4444', tension: 0.4, pointRadius: 2, borderWidth: 1.5 },
                { label: 'Y', data: slice.map(d => d.accel_y), borderColor: '#f59e0b', tension: 0.4, pointRadius: 2, borderWidth: 1.5 },
                { label: 'Z', data: slice.map(d => d.accel_z), borderColor: '#10b981', tension: 0.4, pointRadius: 2, borderWidth: 1.5 }
            ]
        },
        options: {
            responsive: true,
            plugins: { legend: { display: true, position: 'top', labels: { boxWidth: 10, font: { size: 10 } } } },
            scales: { x: { grid: { color: '#f1f5f9' } }, y: { grid: { color: '#f1f5f9' } } }
        }
    });
}

function prevAccel() { if (accelSlide > 0) { accelSlide--; renderAccelSlide(); } }
function nextAccel() { if (accelSlide < Math.ceil(phpLogs.length / PAGE) - 1) { accelSlide++; renderAccelSlide(); } }

function renderSlide() {
    const total = Math.max(1, Math.ceil(allStatusData.length / PAGE));
    const slice = allStatusData.slice(currentSlide * PAGE, (currentSlide + 1) * PAGE);
    document.getElementById('slideInfo').textContent = 'Slide ' + (currentSlide + 1) + ' / ' + total;
    if (statusChart) statusChart.destroy();
    statusChart = new Chart(document.getElementById('statusChart'), {
        type: 'bar',
        data: {
            labels: slice.map(d => fmtLabel(d.timestamp)),
            datasets: [{
                label: 'Status Longsor',
                data: slice.map(d => statusToNumber(d.status)),
                backgroundColor: slice.map(d => getStatusColor(d.status).bg),
                borderColor: slice.map(d => getStatusColor(d.status).border),
                borderWidth: 1.5, borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { display: false } },
            scales: {
                y: {
                    min: 0, max: 3.5, grid: { color: '#f1f5f9' },
                    ticks: { stepSize: 1, callback: v => { if(v==1) return 'AMAN'; if(v==2) return 'WASPADA'; if(v==3) return 'BAHAYA'; return ''; } }
                },
                x: { grid: { color: '#f1f5f9' } }
            }
        }
    });
}

function prevSlide() { if (currentSlide > 0) { currentSlide--; renderSlide(); } }
function nextSlide() { if (currentSlide < Math.ceil(allStatusData.length / PAGE) - 1) { currentSlide++; renderSlide(); } }

function initCharts() {
    moistSlide = Math.max(0, Math.ceil(phpLogs.length / PAGE) - 1);
    accelSlide = moistSlide;
    renderMoistureSlide();
    renderAccelSlide();

    fetch('/api/status-history')
        .then(r => r.json())
        .then(data => {
            allStatusData = data;
            currentSlide = Math.max(0, Math.ceil(data.length / PAGE) - 1);
            renderSlide();
        })
        .catch(() => {
            allStatusData = phpLogs.map(l => ({ timestamp: l.timestamp, status: l.status_ai }));
            currentSlide = Math.max(0, Math.ceil(allStatusData.length / PAGE) - 1);
            renderSlide();
        });
}

let autoRefreshEnabled = true;
let autoRefreshInterval = null;

function toggleAutoRefresh() {
    autoRefreshEnabled = !autoRefreshEnabled;
    const btn = document.getElementById('refreshToggleBtn');
    if (autoRefreshEnabled) {
        btn.textContent = '● Aktif';
        btn.className = 'px-3 py-1 text-xs font-bold rounded-lg bg-emerald-100 text-emerald-700 hover:bg-emerald-200 transition-colors';
        startAutoRefresh();
    } else {
        btn.textContent = '○ Nonaktif';
        btn.className = 'px-3 py-1 text-xs font-bold rounded-lg bg-slate-100 text-slate-500 hover:bg-slate-200 transition-colors';
        if (autoRefreshInterval) clearInterval(autoRefreshInterval);
    }
}

function updateDOMWithLatest(d) {
    if (!d) return;
    const status = (d.status_ai || '').toString().toUpperCase();

    const card = document.getElementById('statusCard');
    const txt = document.getElementById('statusText');
    card.className = 'transition-all duration-300 rounded-2xl shadow-sm p-6 flex flex-col md:flex-row md:items-center justify-between border-l-4 gap-4 ';
    if (status === 'BAHAYA') {
        card.className += 'bg-rose-50 border-rose-500';
        txt.className = 'text-3xl font-extrabold tracking-tight text-rose-700';
        txt.textContent = '⚠ BAHAYA : EVAKUASI SEGERA';
    } else if (status === 'WASPADA') {
        card.className += 'bg-yellow-50 border-yellow-500';
        txt.className = 'text-3xl font-extrabold tracking-tight text-yellow-700';
        txt.textContent = '⚡ WASPADA : SIAGA PENUH';
    } else {
        card.className += 'bg-white border-emerald-500';
        txt.className = 'text-3xl font-extrabold tracking-tight text-emerald-700';
        txt.textContent = '✓ SISTEM AMAN';
    }

    const setEl = (id, val) => { const el = document.getElementById(id); if(el) el.textContent = val; };
    setEl('valMoisture', parseFloat(d.soil_moisture || 0).toFixed(1));
    setEl('valPitch', parseFloat(d.pitch || 0).toFixed(2));
    setEl('valRoll', parseFloat(d.roll || 0).toFixed(2));
    setEl('valVibration', parseFloat(d.vibration || 0).toFixed(3));
    setEl('lastUpdate', d.timestamp || '—');

    const accelEl = document.getElementById('valAccel');
    if (accelEl) {
        const xs = accelEl.querySelectorAll('span.text-base');
        if (xs[0]) xs[0].textContent = parseFloat(d.accel_x||0).toFixed(2);
        if (xs[1]) xs[1].textContent = parseFloat(d.accel_y||0).toFixed(2);
        if (xs[2]) xs[2].textContent = parseFloat(d.accel_z||0).toFixed(2);
    }
    const gyroEl = document.getElementById('valGyro');
    if (gyroEl) {
        const ys = gyroEl.querySelectorAll('span.text-base');
        if (ys[0]) ys[0].textContent = parseFloat(d.gyro_x||0).toFixed(2);
        if (ys[1]) ys[1].textContent = parseFloat(d.gyro_y||0).toFixed(2);
        if (ys[2]) ys[2].textContent = parseFloat(d.gyro_z||0).toFixed(2);
    }

    const now = new Date();
    const timeStr = now.getHours().toString().padStart(2,'0') + ':' + now.getMinutes().toString().padStart(2,'0') + ':' + now.getSeconds().toString().padStart(2,'0');
    setEl('lastRefreshTime', timeStr);
}

function startAutoRefresh() {
    if (autoRefreshInterval) clearInterval(autoRefreshInterval);
    autoRefreshInterval = setInterval(() => {
        if (!autoRefreshEnabled) return;
        fetch('/api/sensor-now')
            .then(r => r.json())
            .then(d => updateDOMWithLatest(d))
            .catch(() => {});
    }, 10000);
}

function appendChat(role, text) {
    const log = document.getElementById('chatLog');
    const div = document.createElement('div');
    div.className = 'flex gap-2 ' + (role === 'user' ? 'flex-row-reverse' : '');
    const avatar = document.createElement('div');
    avatar.className = 'w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 text-[9px] font-bold ' + (role === 'user' ? 'bg-blue-100 text-blue-600' : 'bg-indigo-100 text-indigo-600');
    avatar.textContent = role === 'user' ? 'OP' : 'AI';
    const bubble = document.createElement('div');
    bubble.className = 'rounded-xl px-3 py-2 text-slate-600 max-w-[85%] text-xs ' + (role === 'user' ? 'bg-blue-50 text-blue-800' : 'bg-slate-50');
    bubble.textContent = text;
    div.appendChild(avatar);
    div.appendChild(bubble);
    log.appendChild(div);
    log.scrollTop = log.scrollHeight;
}

function sendChat() {
    const input = document.getElementById('chatInput');
    const msg = input.value.trim();
    if (!msg) return;
    input.value = '';
    appendChat('user', msg);

    const typingDiv = document.createElement('div');
    typingDiv.id = 'typing-indicator';
    typingDiv.className = 'flex gap-2';
    typingDiv.innerHTML = '<div class="w-6 h-6 rounded-full bg-indigo-100 flex items-center justify-center flex-shrink-0 mt-0.5 text-[9px] font-bold text-indigo-600">AI</div><div class="bg-slate-50 rounded-xl px-3 py-2 text-slate-400 text-xs italic max-w-[85%]">Memproses...</div>';
    document.getElementById('chatLog').appendChild(typingDiv);
    document.getElementById('chatLog').scrollTop = document.getElementById('chatLog').scrollHeight;

    fetch('/api/chatbot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.content || '' },
        body: JSON.stringify({ message: msg })
    })
    .then(r => r.json())
    .then(d => {
        document.getElementById('typing-indicator')?.remove();
        appendChat('ai', d.reply || 'Tidak ada respons.');
    })
    .catch(() => {
        document.getElementById('typing-indicator')?.remove();
        appendChat('ai', 'Error: Koneksi ke AI engine gagal.');
    });
}

document.getElementById('chatInput')?.addEventListener('keydown', e => { if (e.key === 'Enter') sendChat(); });
</script>

<!-- CSRF Token for chatbot -->
<meta name="csrf-token" content="{{ csrf_token() }}">

</body>
</html>